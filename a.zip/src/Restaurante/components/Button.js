import React from "react"

const Button = (props) => (
  <button className="button" {...props} />
);

export default Button